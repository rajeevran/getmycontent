jQuery(window).on("load", function() {
  

	
	$("#dashboard").on('click', function() {
	   
		$( "#dashboard" ).addClass( "navSelectedClass" )
		$( "#userRating" ).removeClass( "navSelectedClass" )
		$( "#credit" ).removeClass( "navSelectedClass" )
		$( "#userlist" ).removeClass( "navSelectedClass" )
		$( "#faq" ).removeClass( "navSelectedClass" )
		$( "#cms" ).removeClass( "navSelectedClass" )
		$( "#partnerMang" ).removeClass( "navSelectedClass" )
		$( "#studioMan" ).removeClass( "navSelectedClass" )
		$( "#changePassword" ).removeClass( "navSelectedClass" )
		$( "#contactus" ).removeClass( "navSelectedClass" )
		$( "#blog" ).removeClass( "navSelectedClass" )
		$( "#blogcat" ).removeClass( "navSelectedClass" )
		$( "#passmng" ).removeClass( "navSelectedClass" )
		$( "#userChat" ).removeClass( "navSelectedClass" )

	});
	$(".dashboardCls").on('click', function() {
	   
		$( "#dashboard" ).addClass( "navSelectedClass" )
		$( "#userRating" ).removeClass( "navSelectedClass" )
		$( "#credit" ).removeClass( "navSelectedClass" )
		$( "#userlist" ).removeClass( "navSelectedClass" )
		$( "#faq" ).removeClass( "navSelectedClass" )
		$( "#cms" ).removeClass( "navSelectedClass" )
		$( "#partnerMang" ).removeClass( "navSelectedClass" )
		$( "#studioMan" ).removeClass( "navSelectedClass" )
		$( "#changePassword" ).removeClass( "navSelectedClass" )
		$( "#contactus" ).removeClass( "navSelectedClass" )
		$( "#blog" ).removeClass( "navSelectedClass" )
		$( "#blogcat" ).removeClass( "navSelectedClass" )
		$( "#passmng" ).removeClass( "navSelectedClass" )
		$( "#userChat" ).removeClass( "navSelectedClass" )

	});
  
	$("#changePassword").on('click', function() {
	   
		$( "#changePassword" ).addClass( "navSelectedClass" )
		$( "#userRating" ).removeClass( "navSelectedClass" )
		$( "#credit" ).removeClass( "navSelectedClass" )
		$( "#userlist" ).removeClass( "navSelectedClass" )
		$( "#faq" ).removeClass( "navSelectedClass" )
		$( "#cms" ).removeClass( "navSelectedClass" )
		$( "#dashboard" ).removeClass( "navSelectedClass" )
		$( "#studioMan" ).removeClass( "navSelectedClass" )
		$( "#partnerMang" ).removeClass( "navSelectedClass" )
		$( "#contactus" ).removeClass( "navSelectedClass" )
		$( "#blog" ).removeClass( "navSelectedClass" )
		$( "#blogcat" ).removeClass( "navSelectedClass" )
		$( "#passmng" ).removeClass( "navSelectedClass" )
		$( "#userChat" ).removeClass( "navSelectedClass" )

		
        
	});
	
});


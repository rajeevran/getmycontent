export let CONFIG: any = {
    API_ENDPOINT: 'http://161.35.161.93:9000/',
    API_FRONTEND: 'http://161.35.161.93:9000/api/v1/getMyContent/'
  };
  